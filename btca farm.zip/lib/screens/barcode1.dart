import 'package:flutter/material.dart';
// import 'package:barcode_scan/barcode_scan.dart';

class QRSCan2 extends StatelessWidget {
  const QRSCan2({ Key? key }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      
    );
  }
}