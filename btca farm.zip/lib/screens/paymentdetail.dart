import 'package:flutter/material.dart';

class PaymentDetail extends StatelessWidget {
  // const PaymentDetail({super.key});

  @override
  Widget build(BuildContext context) {
    return Container();
  }
}