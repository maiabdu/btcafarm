import 'package:flutter/material.dart';


Color kPrimaryColor = const Color.fromRGBO(94, 80, 201, 1);
const  COLOR_PRIMARY = 0xFF5E50C9;

